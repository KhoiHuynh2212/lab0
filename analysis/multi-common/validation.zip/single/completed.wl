Job Id,arrival time,Tasks
j0,2,[]
j1,4,[]
j2,6,[]
