Job Id,arrival time,Tasks
j0,0,['0: W 3']
j1,0,['0: W 3']
