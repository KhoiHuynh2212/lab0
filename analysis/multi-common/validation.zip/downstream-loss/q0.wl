Job Id,arrival time,Tasks
j0,0,['0: W 2']
j1,0,['0: W 2']
j2,0,['0: W 2']
