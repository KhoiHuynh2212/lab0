Job Id,arrival time,Tasks
j1,0,['0: W 2']
