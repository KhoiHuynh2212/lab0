Job Id,arrival time,Tasks
j0,3,[]
j1,3,[]
j2,4,[]
j3,4,[]
